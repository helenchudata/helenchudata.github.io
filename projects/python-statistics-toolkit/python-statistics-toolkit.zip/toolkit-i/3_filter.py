import data_generator as dg # Creates a random list of int between -5 and 10. 
data = dg.data_set # Assigns the list of random int to a variable data

print("Calculating non-negative values using data: ",data)

# Filter file
positives = [] # Initializes a variable to hold new list

for num in data : # Uses a for loop to iterate over the data list 
  if num >= 0: # Checks if the number is positive or zero
    positives.append(num) # Appends the number to the positives list
    
print(f"Filtered list: {positives}")