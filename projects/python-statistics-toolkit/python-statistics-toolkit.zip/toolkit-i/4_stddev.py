import data_generator as dg # Creates a random list of int between -5 and 10. 
data = dg.data_set # Assigns the list of random int to a variable data

print("Calculating standard deviation using data: ",data)

# Standard deviation file
total_sum = 0 # Calculates the average
for num in data:   
  total_sum += num 
average = total_sum / len(data) 

squared_sum = 0 # Finds the squared difference and their sum
for num in data:
  squared_difference = (num - average) ** 2 # Subtracts the average and square the result
  squared_sum += squared_difference # The sum of the squared differences and stores it

squared_mean = squared_sum / len(data) # Finds the mean of the squared differences

stddev = squared_mean ** 0.5 # Finds the square root of squared_mean

print(f"The standard deviation of your data is {stddev}.")
