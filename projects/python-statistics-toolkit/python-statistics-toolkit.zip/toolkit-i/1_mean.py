import data_generator as dg # Creates a random list of int between -5 and 10. 
data = dg.data_set # Assigns the list of random int to a variable data

print("Calculating mean using data: ", data)

# Mean file
total_sum = 0 # Creates a variable to hold the sum of the list 

for num in data: # Uses a for-loop of the data list 
  total_sum += num # Adds each number to the sum variable 

mean = total_sum / len(data) # Divides the sum by the number of values in the data list using length of data

print(f"The mean of your data is {mean}.")