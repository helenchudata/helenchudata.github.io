import data_generator as dg # Creates a random list of int between -5 and 10. 
data = dg.data_set # Assigns the list of random int to a variable data

print("Calculating median using data: ", data)

# Median file
sorted_data = sorted(data) # Sorts the list

length = len(sorted_data) # Determines the length of the list

if length % 2 == 0: # Uses an if-else statement to determine if the list is even or odd. This is if it's even.
  middle1 = sorted_data[length // 2 - 1] # The first middle number
  middle2= sorted_data[length // 2] # The second middle number
  median = (middle1+ middle2) / 2 # Average of the two middle numbers
else: # This is if the list is odd
  median = sorted_data[length // 2] # The median is the middle number

print(f"The median of your data is {median}.")