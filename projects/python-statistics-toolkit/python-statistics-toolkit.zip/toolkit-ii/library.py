# TASK 1: Write a function to calculate the mean of a list of integers
def calculate_mean(data):
  """Calculate and return the mean of a list of intergers."""

  return sum(data) / len(data) 


# TASK 2: Write a function that calculates the median of a list of integers
def calculate_median(data):
  """Calculate and return the median of a list of integers."""
  length = len(data)
  sorted_data = sorted(data)
  median = sorted_data[length // 2]

  if length % 2 == 0:
    median = (median + sorted_data[length // 2 - 1]) / 2

  return median

# TASK 3: Write a function that calculates the standard deviation of a list of integers rounded to 2 decimal places
def calculate_stddev(data):
  """Calculate and return the standard deviation of a list of integers."""
  std_mean = calculate_mean(data) # Calculates the mean using defined function

  squared_list = [(val - std_mean) ** 2 for val in data] # Calculates squared differences

  squared_mean = calculate_mean(squared_list) # Calculates the mean of the squared differences

  return round(squared_mean ** 0.5,2) 

# TASK 4: Create a reporting function that returns the result of the given operation
def report(operation, data):
  """Return a report for the requested descriptive satistic."""

  # Dispatches table with the operation as key and function calls as values
  stats = {
    "mean": calculate_mean(data),
    "median": calculate_median(data),
    "std dev": calculate_stddev(data)
  }

  # Checks if the operation is "all" to return the entire dictionary
  if operation == "all":
    return stats
  elif operation in stats:
    return f"The {operation} is {stats[operation]}"
  else:

    return "Invalid operation"