import library 

# TASK 5: Complete the following function to return a list of numbers.
def get_numbers():
  """Asks the user for a list of numebrs and returns them as integers."""

  num_list = []

  while len(num_list) <= 1:
    input_string = input("Enter a list of numbers separated by commas: ").split(",")

  # Checks if each character is numeric
    num_list = [int(item.strip()) for item in input_string if item.strip().isnumeric()]

  return num_list   



# TASK 6: Complete the following function to return an operation
def get_operation():
  """Asks the user which statistic to report on: median, median, std dev, or all."""

  operation = "" # Initializes an empty string for the operation

  # Keeps asking until the operation is one of the choices
  while operation not in ["mean", "median", "std dev", "all"]:
    operation = input("What statistic would you like to know? Please enter mean, median, std dev or all: ")

  return operation  


# TASK 7: Complete the following function to connect the input.py functions to the library.py functions
def get_input():
  """Collect the numbers and operation from the user and return the report."""

  num_list = get_numbers() # Gets the list of numbers 

  operation = get_operation() # Gets the operation

  return library.report(operation, num_list)

    


# IMPORTANT: DO NOT DELETE!
if __name__ == '__main__':
    print(get_input())
