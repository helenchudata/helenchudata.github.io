library(readr)
boat<- read_csv("train.csv")
boat$Survived<-as.factor(boat$Survived)
boatLR<-glm(Survived~Sex,family=binomial(),data=boat)
summary(boatLR)

#Checked missing values in age column
sum(is.na(boat$Age))
boat$AgeAVG<-boat$Age
boat$AgeAVG[is.na(boat$AgeAVG)]<-mean(boat$AgeAVG,na.rm=TRUE)

#Replaced missing embarked values with the most frequent category
sum(is.na(boat$Embarked))
table(boat$Embarked)
boat<-within(boat,Embarked[is.na(Embarked)]<-"S")


boattest<- read_csv("test.csv")
boattest$survive.prod<-predict(boatLR,boattest,type="response")
boattest$survive<-round(boattest$survive.prod)
View(boattest)

sum(is.na(boattest$Age))
boattest$AgeAVG<-boattest$Age
boattest$AgeAVG[is.na(boattest$AgeAVG)]<-mean(boattest$AgeAVG,na.rm=TRUE)

sum(is.na(boattest$Embarked))
table(boattest$Embarked)
boattest<-within(boattest,Embarked[is.na(Embarked)]<-"S")

#Added logistic regression model
boatLR2<-glm(Survived~Sex+Pclass+AgeAVG+SibSp+Parch+Fare,family=binomial(),data=boat)
summary(boatLR2)
boat.prob<-predict(boatLR2,boat,type="response")
table(boat$Survived,boat.prob>.5)
CF<-table(boat$Survived,boat.prob>.5)

#Checked for accuracy
Accuracy<-(CF[2,2]+CF[1,1])/nrow(boat)
Accuracy

boattest$survive.prod<-predict(boatLR2,boattest,type="response")


submission <- c()
submission$PassengerID <-boattest$PassengerId
submission$Survived <-boattest$survive
write.csv(submission, file = "submission.csv")

