library(readr)
boat <- read_csv("titanic.csv")
summary(boat)
head(boat)
tail(boat,10)
summary(boat$Fare)
mean(boat$Fare)
sd(boat$Fare)
var(boat$Fare)

#Scatterplot 1, Age vs. Fare
cor(boat$Age,boat$Fare)
aggregate(Age~Survived,boat,mean)
plot(boat$Age,boat$Fare)
plot(Fare~Age,data=boat)
plot(Fare~Age,data=boat,xlab="Age", ylab="Fare",main="boat")
plot(Fare~Age,data=boat,xlab="Age", ylab="Fare",main="Age vs. Fare",cex.lab=.75)
plot(Fare[which(boat$Survived==0)]~Age[which(boat$Survived==0)],data=boat,
     xlab="Age", ylab="Fare",main="Age vs. Fare",
     cex.lab=.75)
par(new=T)
plot(Fare[which(boat$Survived==1)]~Age[which(boat$Survived==1)],data=boat,
     col="red",xlab="Age", ylab="Fare",main="Age vs. Fare",
     cex.lab=.75)
plot(Fare[which(boat$Survived==1)]~Age[which(boat$Survived==1)],data=boat,
     col="red",xlab="Age", ylab="Fare",main="Age vs. Fare",
     cex.lab=.75)
par(new=T)
plot(Fare[which(boat$Survived==0)]~Age[which(boat$Survived==0)],data=boat,
     xlab='', ylab='', axes=F,
     cex.lab=.75)
abline(lm(boat$Fare~boat$Age), col="darkgreen")

#Scatterplot 2, Ticket Class vs. Fare
cor(boat$Pclass,boat$Fare)
aggregate(Survived~Pclass,boat,mean)
plot(boat$Pclass,boat$Fare)
plot(Fare~Pclass,data=boat)
plot(Fare~Pclass,data=boat,xlab="Ticket Class", ylab="Fare",main="Ticket Class vs. Fare")
plot(Fare~Pclass,data=boat,xlab="Ticket Class", ylab="Fare",main="Ticket Class vs. Fare",cex.lab=.75)
plot(Fare[which(boat$Survived==0)]~Pclass[which(boat$Survived==0)],data=boat,
     xlab="Ticket Class", ylab="Fare",main="Ticket Class vs. Fare",
     cex.lab=.75)
par(new=T)
plot(Fare[which(boat$Survived==1)]~Pclass[which(boat$Survived==1)],data=boat,
     col="red",xlab="Ticket Class", ylab="Fare",main="Ticket Class vs. Fare",
     cex.lab=.75)
plot(Fare[which(boat$Survived==1)]~Pclass[which(boat$Survived==1)],data=boat,
     col="red",xlab="Ticket Class", ylab="Fare",main="Ticket Class vs. Fare",
     cex.lab=.75)
par(new=T)
plot(Fare[which(boat$Survived==0)]~Pclass[which(boat$Survived==0)],data=boat,
     xlab='', ylab='', axes=F,
     cex.lab=.75)
abline(lm(boat$Fare~boat$Pclass), col="darkgreen")

#Boxplot 1, Sex vs. Fare
aggregate(Survived~Sex,boat,mean)
summary(boat$Fare)
boxplot(boat$Fare)
boxplot(boat$Fare~boat$Sex)
boxplot(boat$Fare~boat$Sex,xlab="Sex",ylab="Fare",main="Titanic", 
        cex.axis=0.75)
boxplot(Fare~Sex,data=boat,
        col=(c("#5b85e7","#b32025")),
        names=c("Female","Male"))
legend("topright",legend=c
       ("Female","Male"),pch=c(19,19),
       col=(c("#5b85e7","#b32025")),cex=.75)

boatLM<-lm(boat$Fare~boat$Age)
summary(boatLM)
coef(boatLM)
summary(boatLM)$r.squared

boatLM2<-lm(boat$Fare~boat$Pclass)
summary(boatLM2)
coef(boatLM2)
summary(boatLM2)$r.squared

boatLM3<-lm(boat$Fare~boat$Sex)
summary(boatLM3)
coef(boatLM3)
summary(boatLM3)$r.squared

