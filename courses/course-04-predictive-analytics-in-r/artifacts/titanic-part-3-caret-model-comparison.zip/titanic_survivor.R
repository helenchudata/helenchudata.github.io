library(readr)
library(caTools)
library(FNN)
library(tree)
library(kernlab)
library(neuralnet)
library(caret)
boat<- read_csv("train.csv")
boat$Survived<-as.factor(boat$Survived)

head(boat)
summary(boat)
View(boat)

#for checking the variable Age for missing variables and replacing them with the mean Age.
boat<-within(boat,Age[is.na(Age)]<-mean(Age,na.rm=TRUE))

boattest<- read_csv("test.csv")
View(boattest)

boattest<-within(boattest,Age[is.na(Age)]<-mean(Age,na.rm=TRUE))

#set random seed. 
set.seed(123) 

#use the sample() function to split the data into 80% train, 20% test.
sample<- sample.split(boat$Survived, SplitRatio = .80)
train<- subset(boat, sample == TRUE)
test<- subset(boat, sample == FALSE)

#add logistic regression model.
boatLR<-glm(Survived~Sex+Age+SibSp+Parch,family=binomial(),data=boat)
summary(boatLR)

#use the train() function in caret to tune k-nearest neighbors.
Model<-train(Survived~Sex+Age+SibSp+Parch,data = train, method = "knn")
Model
Model$finalModel

#calculate RMSE - using predict() and postResample().
test_PR<-predict(Model,test)
postResample(pred = test_PR, obs = test$Survived)

#change control options bootstrapping to cross-validation.
trControlOptions<-trainControl(method="cv",number=10,selectionFunction ="best")

#call regression tree and optimize over in kappa.
Model<-train(Survived~Sex+Age+SibSp+Parch,data=train,method="rpart",trControl=trControlOptions,metric="Kappa")
table(predict(Model,boat),boat$Survived)
Model$finalModel

#calculate RMSE - using predict() and postResample().
test_PR<-predict(Model,test)
postResample(pred = test_PR, obs = test$Survived)

boattest$survive.prod<-predict(boatLR,boattest,type="response")
boattest$survive<-round(boattest$survive.prod)
View(boattest)

submission <- c()
submission$PassengerID <-boattest$PassengerId
submission$Survived <-boattest$survive
write.csv(submission, file = "submission.csv")